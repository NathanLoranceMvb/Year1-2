-- Opdracht 1

-- Opdracht 2 

-- Opdracht 3

-- Opdracht 4

-- Opdracht 5
