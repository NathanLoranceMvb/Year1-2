# Antwoorden

## One to One
1.      <->
2.      <->
3.      <->

## One to Many
1.      <->
2.      <->
3.      <->
   
## Many to Many
1.      <->
2.      <->
3.      <->