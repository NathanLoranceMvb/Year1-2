# Antwoorden opdracht 1

Antwoord in bytes:

Antwoord in kilobytes:

# Antwoorden opdracht 2

Hoeveel scheelt het in kilobytes voor de `platform` kolom?

Hoeveel scheelt het in kilobytes voor de `genre` kolom?

Hoeveel scheelt het in kilobytes voor de `publisher` kolom?
