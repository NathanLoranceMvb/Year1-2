-- Opdracht 1 (LETOP: 6 INSERT INTO statements inleveren)


